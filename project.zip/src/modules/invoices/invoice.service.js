import { db } from "../../infrastructure/db/index.js";
import { invoices, invoiceItems , invoicePayments, invoiceStatusHistory, journalEntries, entryLines, accounts } from "../../infrastructure/db/schema.js";
import { and, eq, gt, inArray , lt, desc, sql } from "drizzle-orm";
import { assertTransition, statusThatCanReach  } from "./invoice.state.js";
import { createJournalEntryTx } from "../ledger/ledger.service.js";
import { AppError } from "../../lib/AppError.js";
import { fingerprint } from "../../lib/idempotency.js";
import { decodeSequenceCursor, encodeSequenceCursor } from "../../lib/cursor.js";
import { serializePayment } from "../../lib/serialize.js";

export async function createInvoice({tenantId, customerName, currency, dueDate, items}){
    if(!items||items.length===0) throw new AppError("Invoice must have atleast one item", 422, "INVALID_INVOICE");

    //Calculate Total
    const totalAmountMinor = items.reduce((total, item) => {
        const quantity = BigInt(item.quantity);
        const unitPriceMinor = BigInt(item.unitPriceMinor);

        return total + quantity*unitPriceMinor;
    },0n);

    return await db.transaction(async (tx) => {
        const { sequence, invoiceNumber} = await allocateInvoiceNumber(tx, tenantId);
        const[invoice] = await tx
            .insert(invoices)
            .values({tenantId, invoiceNumber, sequenceNumber: sequence, customerName, currency, dueDate: new Date(dueDate), totalAmountMinor})
            .returning();

        await tx.insert(invoiceItems).values(
            items.map((item) => ({invoiceId: invoice.id, description: item.description, quantity: item.quantity, unitPriceMinor: BigInt(item.unitPriceMinor)
            })),
        );

        await tx.insert(invoiceStatusHistory).values({
            invoiceId: invoice.id,
            fromStatus: null,
            toStatus: "DRAFT",
            reason: "Invoice created"

        });

        return invoice;
    })
}

// Issuing recognises the receivable: debit AR, credit revenue, for the total.
// Payments later credit AR, so a fully paid invoice nets AR back to zero.
export async function issueInvoice(invoiceId, tenantId, { receivableAccountId, revenueAccountId } = {}) {
    return await db.transaction(async(tx) => {
        const [invoice] = await tx.select().from(invoices).where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId,tenantId))).for("update").limit(1);
        if(!invoice) throw new AppError("Invoice not found", 404, "NOT_FOUND");
        assertTransition(invoice.status, "ISSUED");

        const [receivableAccount] = await tx.select().from(accounts)
            .where(and(eq(accounts.id, receivableAccountId), eq(accounts.tenantId, tenantId))).limit(1);
        const [revenueAccount] = await tx.select().from(accounts)
            .where(and(eq(accounts.id, revenueAccountId), eq(accounts.tenantId, tenantId))).limit(1);

        if(!receivableAccount || !revenueAccount) throw new AppError("One or more accounts are invalid", 422, "INVALID_ACCOUNT");
        if(receivableAccount.type !== "ASSET" || revenueAccount.type !== "REVENUE"){
            throw new AppError("The receivable account must be an ASSET and the revenue account a REVENUE account", 422, "INVALID_ACCOUNT_TYPE");
        }
        if(receivableAccount.currency !== invoice.currency || revenueAccount.currency !== invoice.currency){
            throw new AppError("Issue accounts must match the invoice currency", 422, "CURRENCY_MISMATCH");
        }

        const issueDate = new Date();
        const { entry: journalEntry } = await createJournalEntryTx({
            tx,
            tenantId,
            idempotencyKey: `invoice-issue:${invoice.id}`,
            data: {
                description: `Invoice ${invoice.invoiceNumber} issued`,
                occurredAt: issueDate,
                lines: [
                    { accountId: receivableAccountId, amountMinor: invoice.totalAmountMinor },
                    { accountId: revenueAccountId, amountMinor: -invoice.totalAmountMinor },
                ],
            },
        });

        const[updatedInvoice] = await tx
            .update(invoices)
            .set({status:"ISSUED", issueDate, issueJournalEntryId: journalEntry.id, updatedAt: issueDate })
            .where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId,tenantId)))
            .returning();

        await tx.insert(invoiceStatusHistory).values({
            invoiceId: invoice.id,
            fromStatus: invoice.status,
            toStatus: "ISSUED",
            reason: "Invoice issued"
        });
        return updatedInvoice;
    });
}

export async function createInvoicePayment({
    invoiceId, tenantId, amountMinor, paidAt, bankAccountId, accountReceivableAccountId, idempotencyKey,
}){
    return await db.transaction(async (tx) => {

        //Find invoice, locked against concurrent payments
        const[invoice] = await tx
            .select().from(invoices)
            .where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId,tenantId)))
            .for("update")
            .limit(1);
        if(!invoice) throw new AppError("Invoice not found", 404, "NOT_FOUND");

        const requestFingerprint = fingerprint({
            invoiceId,amountMinor,paidAt,bankAccountId,accountReceivableAccountId,
        });
        const effectivePaidAt = paidAt ? new Date(paidAt) : new Date();

        const [payment] = await tx
            .insert(invoicePayments)
            .values({invoiceId, tenantId, amountMinor, paidAt: effectivePaidAt, journalEntryId: null, idempotencyKey, requestFingerprint})
            .onConflictDoNothing({
                target: [invoicePayments.tenantId, invoicePayments.idempotencyKey],
            })
            .returning()

        if(!payment) return await replayPayment({tx,tenantId,idempotencyKey,requestFingerprint});

        const [bankAccount] = await tx.select().from(accounts)
            .where(and(eq(accounts.id, bankAccountId), eq(accounts.tenantId, tenantId))).limit(1);
        const [receivableAccount] = await tx.select().from(accounts)
            .where(and(eq(accounts.id, accountReceivableAccountId), eq(accounts.tenantId, tenantId))).limit(1);

        if(!bankAccount || !receivableAccount) throw new AppError("One or more accounts are invalid", 422, "INVALID_ACCOUNT");
        if(bankAccount.currency !== invoice.currency || receivableAccount.currency !== invoice.currency){
            throw new AppError("Payment accounts must match the invoice currency", 422, "CURRENCY_MISMATCH");
        }

        // The payment must credit the receivable the issue entry debited.
        // Invoices issued before issue posting have no entry and skip this.
        if(invoice.issueJournalEntryId){
            const [issueLine] = await tx.select().from(entryLines)
                .where(and(
                    eq(entryLines.entryId, invoice.issueJournalEntryId),
                    eq(entryLines.tenantId, tenantId),
                    gt(entryLines.amountMinor, 0n),
                ))
                .limit(1);
            // A missing issue line is corrupt data, not a bad request: plain Error -> 500.
            if(!issueLine) throw new Error(`Issue journal entry ${invoice.issueJournalEntryId} for invoice ${invoice.id} has no receivable line`);
            if(issueLine.accountId !== accountReceivableAccountId){
                throw new AppError("Payment must credit the receivable account used when the invoice was issued", 422, "RECEIVABLE_ACCOUNT_MISMATCH");
            }
        }

        const allPayments = await tx.select().from(invoicePayments)
            .where(eq(invoicePayments.invoiceId, invoiceId));
        const paidAmountMinor = allPayments.reduce((t,p) => t + p.amountMinor, 0n);

        if(paidAmountMinor> invoice.totalAmountMinor) throw new AppError ("Payment exceeds remaining invoice amount", 422, "PAYMENT_EXCEEDS_REMAINING");

        const targetStatus = paidAmountMinor === invoice.totalAmountMinor ? "PAID" : "PARTIALLY_PAID";
        try {
            assertTransition(invoice.status, targetStatus);
        } catch {
            throw new AppError(
                `Cannot make payment on ${invoice.status} invoice`, 422, "NOT_PAYABLE"
            );
        }

        //Create ledger entry
        const { entry: journalEntry } = await createJournalEntryTx({
            tx,
            tenantId,
            idempotencyKey: `payment: ${payment.id}`,
            data: {
                description: `Payment for invoice ${invoice.invoiceNumber}`,
                occurredAt: effectivePaidAt,
                lines: [
                    {
                        accountId: bankAccountId,
                        amountMinor
                    },
                    {
                        accountId: accountReceivableAccountId,
                        amountMinor: -amountMinor
                    }
                ]
            }
        });

        const [linkedPayment] = await tx.update(invoicePayments)
            .set({journalEntryId: journalEntry.id})
            .where(eq(invoicePayments.id, payment.id))
            .returning()

        if (targetStatus !== invoice.status) {
            await tx.insert(invoiceStatusHistory).values({
                invoiceId: invoice.id,
                fromStatus: invoice.status,
                toStatus: targetStatus,
                reason: "Payment received"
            });
        }

        //Update invoice
        const [updatedInvoice] = await tx
            .update(invoices)
            .set({status: targetStatus, updatedAt: new Date()})
            .where(and(eq(invoices.id, invoiceId), eq(invoices.tenantId, tenantId)))
            .returning();

        return{ payment: linkedPayment, invoice: updatedInvoice, journalEntry, replayed: false};
    });
}

export async function voidInvoice(invoiceId, tenantId){
    return await db.transaction(async (tx) =>{
        const [invoice] = await tx
            .select().from(invoices).where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId,tenantId))).for("update").limit(1);

        if(!invoice) throw new AppError("Invoice not found", 404, "NOT_FOUND");
        assertTransition(invoice.status, "VOID");

        // A paid invoice is corrected with a credit note, not voided: voiding
        // it here would leave received money in the ledger against a voided
        // invoice with no reversal.
        const payments = await tx.select().from(invoicePayments)
            .where(eq(invoicePayments.invoiceId, invoiceId));
        const paidAmountMinor = payments.reduce((t, p) => t + p.amountMinor, 0n);
        if(paidAmountMinor > 0n){
            throw new AppError(
                "Cannot void an invoice that has payments recorded; issue a credit note instead",
                422,
                "INVOICE_HAS_PAYMENTS",
            );
        }

        const [updatedInvoice] = await tx
            .update(invoices)
            .set({status: "VOID", updatedAt: new Date()})
            .where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId,tenantId)))
            .returning();

        await tx.insert(invoiceStatusHistory).values({
            invoiceId: invoice.id,
            fromStatus: invoice.status,
            toStatus: "VOID",
            reason: "Invoice voided"
        });

        return updatedInvoice;
    });
}

export async function markOverdueInvoices(){
    const now = new Date();
    return await db.transaction(async (tx) => {
        const overdueSources = statusThatCanReach("OVERDUE");
        const overdueCandidates = await tx
        .select().from(invoices)
        .where(and(
            inArray(invoices.status, overdueSources),
            lt(invoices.dueDate,now)
        ));

        const updatedInvoices = [];
        for(const invoice of overdueCandidates){
            const[updatedInvoice] = await tx
                .update(invoices)
                .set({status: "OVERDUE", updatedAt: now})
                .where(
                    and(
                        eq(invoices.id,invoice.id),
                        inArray(invoices.status, overdueSources)
                    )
                )
                .returning();

            if(!updatedInvoice) continue;

            await tx
                .insert(invoiceStatusHistory)
                .values({
                    invoiceId: invoice.id,
                    fromStatus: invoice.status,
                    toStatus: "OVERDUE",
                    reason: "Invoice due date passed"
                });
            updatedInvoices.push(updatedInvoice);
        }
        return updatedInvoices;
    });
}

async function replayPayment({ tx, tenantId, idempotencyKey, requestFingerprint}){
    const [existing] = await tx.select().from(invoicePayments)
        .where(and(
            eq(invoicePayments.tenantId, tenantId),
            eq(invoicePayments.idempotencyKey, idempotencyKey)
        ))
        .limit(1);

    if(existing.requestFingerprint !== requestFingerprint){
        throw new AppError(
            "This Idempotency-Key was already used with a different request body",
            409, "IDEMPOTENCY_KEY_REUSED",
        );
    }

    const [invoice] = await tx.select().from(invoices)
        .where(eq(invoices.id, existing.invoiceId)).limit(1);

    const [journalEntry] = existing.journalEntryId
        ? await tx.select().from(journalEntries).where(eq(journalEntries.id, existing.journalEntryId)).limit(1)
        : [null];

    return { payment: existing, invoice, journalEntry, replayed: true };
}

export async function listInvoices({ tenantId, limit, cursor, status, dueBefore}){
    const filters = [eq(invoices.tenantId, tenantId)];

    if(status) filters.push(inArray(invoices.status, status));
    if(dueBefore) filters.push(lt(invoices.dueDate, dueBefore));

    if(cursor){
        const decoded = decodeSequenceCursor(cursor);
        if(!decoded) throw new AppError("Invalid cursor", 400, "INVALID_CURSOR");
        filters.push(sql`${invoices.sequenceNumber} < ${decoded.sequenceNumber}`);
    }

    const rows = await db
        .select()
        .from(invoices)
        .where(and(...filters))
        .orderBy(desc(invoices.sequenceNumber))
        .limit(limit + 1);

    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;

    const paidByInvoice = new Map();
    if(page.length){
        const sums = await db
            .select({
                invoiceId: invoicePayments.invoiceId,
                paid: sql`COALESCE(SUM(${invoicePayments.amountMinor}), 0) ::text`,
            })
            .from(invoicePayments)
            .where(inArray(invoicePayments.invoiceId, page.map((i) => i.id)))
            .groupBy(invoicePayments.invoiceId);

        for( const row of sums) paidByInvoice.set(row.invoiceId, BigInt(row.paid));  
    }

    return{
        data: page.map((inv) => {
            const paid = paidByInvoice.get(inv.id) ?? 0n;
            return{
                ...inv,
                sequenceNumber: inv.sequenceNumber.toString(),
                totalAmountMinor: inv.totalAmountMinor.toString(),
                paidAmountMinor: paid.toString(),
                outstandingMinor: (inv.totalAmountMinor - paid).toString()
            };
        }),
        nextCursor: hasMore ? encodeSequenceCursor({ sequenceNumber: page.at(-1).sequenceNumber }) : null
    };
}


export async function getInvoice({ tenantId, invoiceId}){
    const [ invoice ] = await db
        .select()
        .from(invoices)
        .where(and(eq(invoices.id,invoiceId), eq(invoices.tenantId, tenantId)));

    if(!invoice) throw new AppError("Invoice not found", 404, "NOT_FOUND");

    const [items, payments, history] = await Promise.all([
        db.select().from(invoiceItems)
            .where(eq(invoiceItems.invoiceId, invoiceId)),
        db.select().from(invoicePayments)
            .where(eq(invoicePayments.invoiceId, invoiceId))
            .orderBy(desc(invoicePayments.createdAt)),
        db.select().from(invoiceStatusHistory)
            .where(eq(invoiceStatusHistory.invoiceId, invoiceId))
            .orderBy(desc(invoiceStatusHistory.changedAt)),
    ]);

    const paid = payments.reduce((sum,p) => sum + p.amountMinor, 0n);

    return{
        ...invoice,
        sequenceNumber: invoice.sequenceNumber.toString(),
        totalAmountMinor: invoice.totalAmountMinor.toString(),
        paidAmountMinor: paid.toString(),
        outstandingMinor: (invoice.totalAmountMinor - paid).toString(),
        items: items.map((i) => ({
            ...i,
            unitPriceMinor: i.unitPriceMinor.toString(),
            lineTotalMinor: (i.unitPriceMinor * BigInt(i.quantity)).toString(),
        })),
        payments: payments.map(serializePayment),
        statusHistory: history,
    };
}

async function allocateInvoiceNumber(tx, tenantId) {
  const { rows } = await tx.execute(sql`
    INSERT INTO invoice_sequences (tenant_id, last_value)
    VALUES (${tenantId}, 1)
    ON CONFLICT (tenant_id)
    DO UPDATE SET last_value = invoice_sequences.last_value + 1,
                  updated_at = now()
    RETURNING last_value
  `);

  const sequence = BigInt(rows[0].last_value);
  return {
    sequence,
    invoiceNumber: `INV-${String(sequence).padStart(6, "0")}`,
  };
}